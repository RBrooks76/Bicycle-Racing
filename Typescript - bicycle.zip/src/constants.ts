export const PX_PER_POSITION = 50;
